/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.project;

import java.awt.Button;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import project.project.ChoosePageController;

/**
 * FXML Controller class
 *
 * @author LTC2020 
 */
public class LoginPageController implements Initializable {

    @FXML
    private Button loginSwitchButton;
    @FXML
    private Button signinSwitchButton;
    @FXML
    private TextField userNameTextField;
    @FXML
    private TextField passwordTextField;

    /**
     * Initializes the controller class.
     */
    Statement statement;

    @FXML
    private Label passwordError;
    @FXML
    private Label userNameError;
    public final static ArrayList<User> users = new ArrayList<>();
    private Object FXMLLoader;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            PrintWriter output2 = new PrintWriter(ChoosePageController.logFile);
            output2.print("\n");
            output2.close();
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/library?serverTimezone=UTC", "root", "");
            statement = conn.createStatement();
            ResultSet s = statement.executeQuery("select * from users");
            while (s.next()) {
                User u = new User(s.getInt("ID"), s.getString("Name"), s.getString("Password"));
                users.add(u);
            }
            FileWriter fw2 = new FileWriter(ChoosePageController.logFile, true);
            BufferedWriter bw2 = new BufferedWriter(fw2);
            PrintWriter output = new PrintWriter(bw2);;
            output.print("***Select All Users In Database To Save It Into Users ArrayList For Processing Data. \n");
            output.close();
        } catch (Exception ex) {
            Logger.getLogger(LoginPageController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void signinSwitchButtonHandel(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(this.getClass().getResource("SignUp_Page.fxml"));
        Scene scene = new Scene(p, 1366, 700);
        Main.setNewScene(scene);
    }

    @FXML
    private void loginSubmitButtonHandel(ActionEvent event) throws IOException {
        userNameError.setText("");
        passwordError.setText("");
        String userName = userNameTextField.getText();
        String password = passwordTextField.getText();
        if (userName.equals("")) {
            userNameError.setText("You should enter you user name !!!");
        }
        if (password.equals("")) {
            passwordError.setText("You should enter your password !!!");
        }
        if ((!userName.equals("")) && (!password.equals(""))) {
            User u1;
            boolean foundUserName = false;
            boolean foundPassword = false;
            for (User user : users) {
                if ((user.getName().equals(userName))) {
                    foundUserName = true;
                }
                if (user.getPassword().equals(password)) {
                    foundPassword = true;
                }
                if (foundPassword && foundUserName) {
                    u1 = new User(userName, password);
                    break;
                }
            }
            if (!foundUserName) {
                userNameError.setText("Not Found UserName !!!");
            }
            if (foundUserName && !foundPassword) {
                passwordError.setText("Incorrct Password !!!");
            }
            if (foundPassword && foundUserName) {
                Parent p = FXMLLoader.load(this.getClass().getResource("ChoosePage.fxml"));
                Scene scene = new Scene(p, 1366, 700);
                Main.setNewScene(scene);
            }
        }

    }

}
