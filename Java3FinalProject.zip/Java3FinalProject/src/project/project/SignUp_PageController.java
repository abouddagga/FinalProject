/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.project;

import java.awt.Button;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author LTC2020  
 */
public class SignUp_PageController implements Initializable {

    @FXML
    private TextField idTextField;
    @FXML
    private TextField userNameTextField;
    @FXML
    private TextField passwordTextField;
    @FXML
    private TextField confirmPasswordTextField;
    @FXML
    private Button signupSwitchButton;
    @FXML
    private Button loginSwitchButton;
    Statement statement;
    @FXML
    private Label idError;
    @FXML
    private Label userNameError;
    @FXML
    private Label passwordError;
    @FXML
    private Label confirmPasswordError;
    @FXML
    private Label succssfullSignUp;
    private Object FXMLLoader;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        signupSwitchButton.setStyle("-fx-text-fill:white;-fx-background-color:#ff971d");
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/library?serverTimezone=UTC", "root", "");
            statement = conn.createStatement();
        } catch (Exception ex) {
            Logger.getLogger(SignUp_PageController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void SignUpSubmitHandel(ActionEvent event) throws SQLException, FileNotFoundException {
        resetTextFeild();
        String idString = idTextField.getText();
        Integer id = null;
        String userName = userNameTextField.getText();
        String password = passwordTextField.getText();
        String conformPassword = confirmPasswordTextField.getText();

        boolean idTypeNotPass = false;
        boolean idEmpty = idString.equals("");
        boolean userNameEmpty = userName.equals("");
        boolean passwordEmpty = password.equals("");
        boolean conformPasswordEmpty = conformPassword.equals("");
        boolean conformPasswordMissmatch = !(conformPassword.equals(password));

        if (idEmpty) {
            idError.setText("Empty ID !!");

        } else {
            try {
                id = Integer.parseInt(idTextField.getText());
            } catch (Exception e) {
                idError.setText("You Should Enter Integer ID.");
                idTypeNotPass = true;
            }
        }
        if (userNameEmpty) {
            userNameError.setText("Empty User Name !!");

        }
        if (passwordEmpty) {
            passwordError.setText("Empty Password !!");
        }
        if (conformPasswordEmpty) {
            confirmPasswordError.setText("Empty ID !!");
        }
        if (conformPasswordMissmatch) {
            confirmPasswordError.setText("Mismatch Password!!");
        }

        if (!(idTypeNotPass || idEmpty || userNameEmpty || passwordEmpty || conformPasswordEmpty || conformPasswordMissmatch)) {
            boolean MissmatchId = true;
            for (User s : LoginPageController.users) {
                if (s.getId() == id) {
                    MissmatchId = false;
                    idError.setText("This Id Is Already Exist.");
                    break;
                }
            }
            if (MissmatchId) {
                statement.executeUpdate("INSERT INTO users VALUES (" + id + ",'" + userName + "','" + password + "')");
                PrintWriter output = new PrintWriter(ChoosePageController.logFile);
                output.append("Add The ID : " + id + " , User Name : '" + userName + 
                        "' , Password : '" + password + "Into users Table In DataBase. \n");
                output.close();

                succssfullSignUp.setText("Successfully Registered");
            }
        }
    }

    @FXML
    private void loginSwitchButtonHandel(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(this.getClass().getResource("LoginPage.fxml"));
        Scene scene = new Scene(p, 1366, 700);
        Main.setNewScene(scene);
    }

    public void resetTextFeild() {
        idError.setText("");
        passwordError.setText("");
        userNameError.setText("");
        confirmPasswordError.setText("");
        succssfullSignUp.setText("");
    }
}
