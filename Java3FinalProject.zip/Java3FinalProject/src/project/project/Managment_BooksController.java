/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.project;

import java.awt.Label;
import java.awt.TextField;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.swing.table.TableColumn;
import javax.swing.text.TableView;

/**
 * FXML Controller class
 *
 * @author LTC2020 
 */
public class Managment_BooksController implements Initializable {

    @FXML
    private TextField idTextFeild;
    @FXML
    private TextField nameTextField;
    @FXML
    private TextField descriptionTextFeild;
    @FXML
    private TableView<Books> Table;
    @FXML
    private TableColumn<Books, Integer> idColmun;
    @FXML
    private TableColumn<Books, String> nameColmun;
    @FXML
    private TableColumn<Books, String> descriptionColmun;
    @FXML
    private Label idError;
    @FXML
    private Label nameError;
    @FXML
    private Label descriptionError;
    public static final ArrayList<Books> books = new ArrayList<>();
    Statement statement;
    private Object FXMLLoader;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/library?serverTimezone=UTC", "root", "");
            statement = conn.createStatement();
            ResultSet s = statement.executeQuery("select * from books");
            books.clear();
            while (s.next()) {
                Books u = new Books(s.getInt("ID"), s.getString("Name"), s.getString("Description"));
                books.add(u);
            }
            Table.getItems().setAll(books);
            FileWriter fw = new FileWriter(ChoosePageController.logFile, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter output = new PrintWriter(bw);
            output.print("***After Clearing Books Array List , Select All Books In Database To Save It Into ArrayList And Show It In Table. \n");
            output.close();
        } catch (Exception ex) {
            Logger.getLogger(LoginPageController.class.getName()).log(Level.SEVERE, null, ex);
        }

        idColmun.setCellValueFactory(new PropertyValueFactory("id"));
        nameColmun.setCellValueFactory(new PropertyValueFactory("name"));
        descriptionColmun.setCellValueFactory(new PropertyValueFactory("description"));
        Table.getSelectionModel().selectedItemProperty().addListener(e -> {
            Books b = Table.getSelectionModel().getSelectedItem();
            if (b != null) {
                idTextFeild.setText(String.valueOf(b.getId()));
                nameTextField.setText(b.getName());
                descriptionTextFeild.setText(b.getDescription());
            }
        });

    }

    @FXML
    private void addButtonHandel(ActionEvent event) throws SQLException, FileNotFoundException, IOException {
        if (Validation()) {
            int id = Integer.parseInt(idTextFeild.getText());
            String name = nameTextField.getText();
            String description = descriptionTextFeild.getText();
            Books g = new Books(id, name, description);
            boolean matchId = false;
            for (Books a : books) {
                if (a.getId() == id) {
                    matchId = true;
                    break;

                }
            }
            if (!matchId) {
                statement.executeUpdate("INSERT INTO books VALUES (" + id + ",'" + name + "','" + description + "')");
                show();
                resetFeilds();
                resetErrorLabels();
                FileWriter fw = new FileWriter(ChoosePageController.logFile, true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter output = new PrintWriter(bw);
                output.print("***Add The Id : " + id + " ,Name : '" + name + "' And Description : '" + description + "' Into books Table In Database\n");
                output.close();

            } else {
                idError.setText("This ID is Already Exist !!");
            }
        }

    }

    @FXML
    private void deleteButtonHandel(ActionEvent event) throws SQLException, FileNotFoundException, IOException {
        if (Validation()) {
            int id = Integer.parseInt(idTextFeild.getText());
            String name = nameTextField.getText();
            String description = descriptionTextFeild.getText();
            Books g = new Books(id, name, description);
            boolean match = false;
            for (Books k : books) {
                if (k.getId() == id) {
                    match = true;
                    break;
                }
            }
            
            if (match) {
                statement.executeUpdate("DELETE FROM books WHERE ID = " + id);
                resetErrorLabels();
                resetFeilds();
                show();
                FileWriter fw = new FileWriter(ChoosePageController.logFile, true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter output = new PrintWriter(bw);
                output.print("***Delete The Id : " + id + " ,Name : '" + name + "' And Description : '" + description + "' From books Table In Database\n");
                output.close();
            } else {
                idError.setText("This ID is Not Exist !!");
            }
        }
    }

    @FXML
    private void updateButtonHandel(ActionEvent event) throws SQLException, FileNotFoundException, IOException {

        if (Validation()) {
            int id = Integer.parseInt(idTextFeild.getText());
            String name = nameTextField.getText();
            String description = descriptionTextFeild.getText();
            Books g = new Books(id, name, description);
            boolean match = false;
            for (Books k : books) {
                if (k.getId() == id) {
                    match = true;
                    break;
                }
            }
            if (match) {
                statement.executeUpdate("Update books SET Name = '" + name + "' , Description = '" + description + "' WHERE ID = " + id);
                resetErrorLabels();
                resetFeilds();
                show();
                FileWriter fw = new FileWriter(ChoosePageController.logFile, true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter output = new PrintWriter(bw);
                output.print("***Update  Name : '" + name + "' And Description : '" + description + "' Thats Have The Id : " + id + " In books Table In Database\n");
                output.close();
            } else {
                idError.setText("This ID is Not Exist !!");
            }
        }
    }

    @FXML
    private void searchButtonHandel(ActionEvent event) {
        resetErrorLabels();
        String idString = idTextFeild.getText();
        Integer id = null;
        boolean idEmpty = idString.equals("");
        boolean idTypeNotPass = false;

        if (idEmpty) {
            idError.setText("Empty ID !!");
        } else {
            try {
                id = Integer.parseInt(idString);
            } catch (Exception d) {
                idError.setText("You Should Enter An Integer Number.");
                idTypeNotPass = true;
            }
        }
        if (!(idEmpty || idTypeNotPass)) {
            Books g = null;
            for (Books a : books) {
                if (a.getId() == id) {
                    g = a;
                    break;
                }
            }

            if (g == null) {
                idError.setText("This ID is Not Exist !!");
            } else {
                nameTextField.setText(g.getName());
                descriptionTextFeild.setText(g.getDescription());
            }
        }
    }

    @FXML
    private void backButtonHandel(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(this.getClass().getResource("ChoosePage.fxml"));
        Scene scene = new Scene(p, 1366, 700);
        Main.setNewScene(scene);
    }

    private boolean Validation() {
        resetErrorLabels();
        String idString = idTextFeild.getText();
        String name = nameTextField.getText();
        String description = descriptionTextFeild.getText();
        Integer id = null;
        boolean idEmpty = idString.equals("");
        boolean idTypeNotPass = false;
        boolean nameEmpty = name.equals("");
        boolean descriptionEmpty = description.equals("");

        if (idEmpty) {
            idError.setText("Empty ID !!");
        } else {
            try {
                id = Integer.parseInt(idString);
            } catch (Exception d) {
                idError.setText("You Should Enter An Integer Number.");
                idTypeNotPass = true;
            }
        }

        if (nameEmpty) {
            nameError.setText("Empty Name !!");
        }

        if (descriptionEmpty) {
            descriptionError.setText("Empty Description !!");
        }

        return !(idEmpty || idTypeNotPass || nameEmpty || descriptionEmpty);
    }

    private void resetErrorLabels() {
        idError.setText("");
        nameError.setText("");
        descriptionError.setText("");
    }

    private void show() throws SQLException, FileNotFoundException, IOException {
        books.clear();
        ResultSet s = statement.executeQuery("select * from books");
        while (s.next()) {
            Books u = new Books(s.getInt("ID"), s.getString("Name"), s.getString("Description"));
            books.add(u);
        }
        Table.getItems().setAll(books);
        FileWriter fw = new FileWriter(ChoosePageController.logFile, true);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter output = new PrintWriter(bw);
        output.print("***After Clearing Books Array List , Select All Books In Database To Save It Into Books ArrayList And Show It In Table. \n");
        output.close();
    }

    private void resetFeilds() {
        idTextFeild.setText("");
        nameTextField.setText("");
        descriptionTextFeild.setText("");
    }
}
