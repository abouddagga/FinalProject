/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.project;

import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;

/**
 * FXML Controller class
 *
 * @author LTC2020  
 */
public class ChoosePageController implements Initializable {

    private User user;

    public static final File logFile = new File("log.txt");
    private Object FXMLLoader;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    @FXML
    private void managment_BooksButtonHandel(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(this.getClass().getResource("Managment_Books.fxml"));
        Scene scene = new Scene(p, 1366, 700);
        Main.setNewScene(scene);
    }

    @FXML
    private void managment_Borrower_BooksButtonHandel(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(this.getClass().getResource("Managment_Borrower_Books.fxml"));
        Scene scene = new Scene(p, 1366, 700);
        Main.setNewScene(scene);
    }

    @FXML
    private void managment_BorrowersButtonHandel(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(this.getClass().getResource("Managment_Borrowers.fxml"));
        Scene scene = new Scene(p, 1366, 700);
        Main.setNewScene(scene);
    }

    @FXML
    private void logoutButtonHandel(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(this.getClass().getResource("LoginPage.fxml"));
        Scene s = new Scene(p);
        Main.setNewScene(s);
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

}
