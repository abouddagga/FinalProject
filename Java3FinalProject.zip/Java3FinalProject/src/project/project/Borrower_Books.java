/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.project;

/**
 *
 * @author LTC2020  
 */
public class Borrower_Books {
    
    private int Book_ID;
    private int Borrower_ID;
    private String Borrowers_Data;
    private String Return_Data;

    public Borrower_Books(int Book_ID, int Borrower_ID, String Borrowers_Data, String Return_Data) {
        this.Book_ID = Book_ID;
        this.Borrower_ID = Borrower_ID;
        this.Borrowers_Data = Borrowers_Data;
        this.Return_Data = Return_Data;
    }

    public Borrower_Books() {
    }

    public int getBook_ID() {
        return Book_ID;
    }

    public void setBook_ID(int Book_ID) {
        this.Book_ID = Book_ID;
    }

    public int getBorrower_ID() {
        return Borrower_ID;
    }

    public void setBorrower_ID(int Borrower_ID) {
        this.Borrower_ID = Borrower_ID;
    }

    public String getBorrowers_Data() {
        return Borrowers_Data;
    }

    public void setBorrowers_Data(String Borrowers_Data) {
        this.Borrowers_Data = Borrowers_Data;
    }

    public String getReturn_Data() {
        return Return_Data;
    }

    public void setReturn_Data(String Return_Data) {
        this.Return_Data = Return_Data;
    }
    
    
    
    
    
}
