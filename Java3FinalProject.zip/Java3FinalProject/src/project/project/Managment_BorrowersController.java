/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.project;

import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.swing.table.TableColumn;
import javax.swing.text.TableView;

/**
 * FXML Controller class
 *
 * @author LTC2020  
 */
public class Managment_BorrowersController implements Initializable {

    @FXML
    private TextField idTextFeild;
    @FXML
    private TextField firstNameTextFeild;
    @FXML
    private TextField lastNameTextFeild;
    @FXML
    private TextField mobileTextFeild;
    @FXML
    private TextField emailTextFeild;
    @FXML
    private TextField addressTextFeild;
    @FXML
    private RadioButton mailReduio;
    @FXML
    private RadioButton femailReduio;
    @FXML
    private TableView<Borrowers> Table;
    @FXML
    private TableColumn<Borrowers, Integer> idColumn;
    @FXML
    private TableColumn<Borrowers, String> firstNameColumn;
    @FXML
    private TableColumn<Borrowers, String> lastNameColumn;
    @FXML
    private TableColumn<Borrowers, Integer> mobileColumn;
    @FXML
    private TableColumn<Borrowers, String> emailColumn;
    @FXML
    private TableColumn<Borrowers, String> adressColumn;
    @FXML
    private TableColumn<Borrowers, String> genderColumn;

    public static final ArrayList<Borrowers> borrowers = new ArrayList<>();
    Statement statement;
    @FXML
    private Label idError;
    @FXML
    private Label firstNameError;
    @FXML
    private Label lastNameError;
    @FXML
    private Label mobileError;
    @FXML
    private Label emailError;
    @FXML
    private Label addressError;
    @FXML
    private Label genderError;
    private Object FXMLLoader;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/library?serverTimezone=UTC", "root", "");
            statement = conn.createStatement();
            borrowers.clear();
            ResultSet s = statement.executeQuery("select * from borrowers");
            while (s.next()) {
                Borrowers u = new Borrowers(s.getInt("ID"), s.getString("FirstName"),
                        s.getString("LastName"), s.getInt("Mobile"), s.getString("Email"), s.getString("Address"), s.getString("Gender"));
                borrowers.add(u);
            }
            Table.getItems().setAll(borrowers);
            FileWriter fw = new FileWriter(ChoosePageController.logFile, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter output = new PrintWriter(bw);
            output.print("***After Clearing Borrowers Array List ,"
                    + "Select All Borrowers In Database To Save It Into Borrowers ArrayList. \n");
            output.close();

        } catch (Exception ex) {
            Logger.getLogger(LoginPageController.class.getName()).log(Level.SEVERE, null, ex);
        }

        idColumn.setCellValueFactory(new PropertyValueFactory("id"));
        firstNameColumn.setCellValueFactory(new PropertyValueFactory("firstName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory("lastName"));
        mobileColumn.setCellValueFactory(new PropertyValueFactory("mobile"));
        emailColumn.setCellValueFactory(new PropertyValueFactory("email"));
        adressColumn.setCellValueFactory(new PropertyValueFactory("address"));
        genderColumn.setCellValueFactory(new PropertyValueFactory("gender"));
        Table.getSelectionModel().selectedItemProperty().addListener(e -> {
            Borrowers b = Table.getSelectionModel().getSelectedItem();
            if (b != null) {
                idTextFeild.setText(String.valueOf(b.getId()));
                firstNameTextFeild.setText(b.getFirstName());
                lastNameTextFeild.setText(b.getLastName());
                mobileTextFeild.setText(String.valueOf(b.getMobile()));
                emailTextFeild.setText(b.getEmail());
                addressTextFeild.setText(b.getAddress());
                if (b.getGender().equals(mailReduio.getText())) {
                    mailReduio.setSelected(true);
                } else {
                    femailReduio.setSelected(true);
                }
            }
        });
    }

    @FXML
    private void addButtonHandel(ActionEvent event) throws SQLException, FileNotFoundException, IOException {

        if (Validation()) {
            int id = Integer.parseInt(idTextFeild.getText());
            String firstName = firstNameTextFeild.getText();
            String lastName = lastNameTextFeild.getText();
            int mobile = Integer.parseInt(mobileTextFeild.getText());
            String email = emailTextFeild.getText();
            String address = addressTextFeild.getText();
            String mailG = mailReduio.getText();
            String femail = femailReduio.getText();
            String geneder = "";
            if (mailReduio.isSelected()) {
                geneder = mailG;
            } else {
                geneder = femail;
            }

            int i = 0;
            for (Borrowers b : borrowers) {
                if (b.getId() == id) {
                    break;
                } else {
                    i++;
                }
            }
            boolean missMatch = borrowers.size() == i;
            if (missMatch) {
                statement.executeUpdate("INSERT INTO borrowers VALUES (" + id + ",'" + firstName + "','" +
                        lastName + "'," + mobile + ",'" + email + "','" + address + "','" + geneder + "')");
                resetErrorLabels();
                show();
                resetFeilds();
                FileWriter fw = new FileWriter(ChoosePageController.logFile, true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter output = new PrintWriter(bw);
                output.print("***Add The ID : " + id + " , First Name : '" + firstName + "' , Last Name : '" 
                        + lastName + "' , Mobile : " + mobile + " , E-Mail : '" + email + "' , Address : '"
                        + address + "' And Gender : '" + geneder + "' Into borrowers Table In DataBase. \n");
                output.close();
            } else {
                idError.setText("This ID Is Aleardy Exist !!");
            }
        }

    }

    @FXML
    private void deleteButtonHandel(ActionEvent event) throws SQLException, FileNotFoundException, IOException {
        if (Validation()) {
            int id = Integer.parseInt(idTextFeild.getText());
            String firstName = firstNameTextFeild.getText();
            String lastName = lastNameTextFeild.getText();
            int mobile = Integer.parseInt(mobileTextFeild.getText());
            String email = emailTextFeild.getText();
            String address = addressTextFeild.getText();
            String mailG = mailReduio.getText();
            String femail = femailReduio.getText();
            String geneder = "";
            if (mailG.endsWith("")) {
                geneder = femail;
            } else {
                geneder = mailG;
            }
            boolean match = false;
            for (Borrowers b : borrowers) {
                if (b.getId() == id) {
                    match = true;
                    break;
                }
            }
            if (match) {
                statement.executeUpdate("DELETE FROM borrowers WHERE ID = " + id);
                resetErrorLabels();
                show();
                resetFeilds();
                FileWriter fw = new FileWriter(ChoosePageController.logFile, true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter output = new PrintWriter(bw);
                output.print("***Delete The ID : " + id + " , First Name : '" + firstName + "' , Last Name : '" + 
                        lastName + "' , Mobile : " + mobile + " , E-Mail : '" + email + "' , Address : '" + address + "' And Gender : '" +
                        geneder + "' From borrowers Table In DataBase. \n");
                output.close();
            } else {
                idError.setText("This ID Is Not Exist !!");
            }

        }
    }

    @FXML
    private void updateButtonHandel(ActionEvent event) throws SQLException, FileNotFoundException, IOException {
        if (Validation()) {
            int id = Integer.parseInt(idTextFeild.getText());
            String firstName = firstNameTextFeild.getText();
            String lastName = lastNameTextFeild.getText();
            int mobile = Integer.parseInt(mobileTextFeild.getText());
            String email = emailTextFeild.getText();
            String address = addressTextFeild.getText();
            String mailG = mailReduio.getText();
            String femail = femailReduio.getText();
            String geneder = "";
            if (mailG.endsWith("")) {
                geneder = femail;
            } else {
                geneder = mailG;
            }
            boolean match = false;
            for (Borrowers b : borrowers) {
                if (b.getId() == id) {
                    match = true;
                    break;
                }
            }
            if (match) {
                statement.executeUpdate("UPDATE borrowers SET ID = " + id + " , FirstName = '" + firstName + 
                        "' , LastName = '" + lastName + "' , Mobile = " + mobile + " , Email = '" + email + 
                        "' , Address = '" + address + "' , Gender = '" + geneder + "' WHERE ID = " + id);
                resetErrorLabels();
                show();
                resetFeilds();
                FileWriter fw = new FileWriter(ChoosePageController.logFile, true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter output = new PrintWriter(bw);
                output.print("***Update The First Name : '" + firstName + "' , Last Name : '" + lastName +
                        "' , Mobile : " + mobile + " , E-Mail : '" + email + "' , Address : '" + address + 
                        "' And Gender : '" + geneder + "' Thats Have The ID : " + id + " In borrowers Table In DataBase. \n");
                output.close();
            } else {
                idError.setText("This ID Is Not Exist !!");
            }

        }
    }

    @FXML
    private void searchButtonHandel(ActionEvent event) {
        resetErrorLabels();
        String idString = idTextFeild.getText();
        Integer id = null;
        boolean idEmpty = idString.equals("");
        boolean idTypeNotPass = false;

        if (idEmpty) {
            idError.setText("Empty ID !!");
        } else {
            try {
                id = Integer.parseInt(idString);
            } catch (Exception d) {
                idError.setText("You Should Enter An Integer Number.");
                idTypeNotPass = true;
            }
        }
        if (!(idEmpty || idTypeNotPass)) {
            Borrowers g = null;
            for (Borrowers a : borrowers) {
                if (a.getId() == id) {
                    g = a;
                    break;
                }
            }

            if (g == null) {
                idError.setText("This ID is Not Exist !!");
            } else {
                firstNameTextFeild.setText(g.getFirstName());
                lastNameTextFeild.setText(g.getLastName());
                mobileTextFeild.setText(String.valueOf(g.getMobile()));
                emailTextFeild.setText(g.getEmail());
                addressTextFeild.setText(g.getAddress());
            }
        }
    }

    @FXML
    private void backButtonHandel(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(this.getClass().getResource("ChoosePage.fxml"));
        Scene scene = new Scene(p, 1366, 700);
        Main.setNewScene(scene);
    }

    private boolean Validation() {
        resetErrorLabels();
        String idString = idTextFeild.getText();
        String firstName = firstNameTextFeild.getText();
        String lastName = lastNameTextFeild.getText();
        String mobileString = mobileTextFeild.getText();
        String email = emailTextFeild.getText();
        String address = addressTextFeild.getText();
        boolean mailG = mailReduio.isSelected();
        boolean femail = femailReduio.isSelected();

        Integer mobile = null;
        Integer id = null;

        boolean idEmpty = idString.equals("");
        boolean idTypeNotPass = false;
        boolean firstNameEmpty = firstName.equals("");
        boolean lastNameEmpty = lastName.equals("");
        boolean mobileStringEmpty = mobileString.equals("");
        boolean mobileTypeNotPass = false;
        boolean emailEmpty = email.equals("");
        boolean addressEmpty = address.equals("");
        boolean genderEmpty = !(mailG || femail);

        if (firstNameEmpty) {
            firstNameError.setText("Empty Name !!");
        }

        if (lastNameEmpty) {
            lastNameError.setText("Empty Last Name !!");
        }
        if (emailEmpty) {
            emailError.setText("Empty E-Mail !!");
        }
        if (addressEmpty) {
            addressError.setText("Empty Address !!");
        }
        if (genderEmpty) {
            genderError.setText("You Should Determined Your Gender.");
        }

        if (idEmpty) {
            idError.setText("Empty ID !!");
        } else {
            try {
                id = Integer.parseInt(idString);
            } catch (Exception d) {
                idError.setText("You Should Enter An Integer Number.");
                idTypeNotPass = true;
            }
        }
        if (mobileStringEmpty) {
            mobileError.setText("Empty Mobile Number !!.");
            mobileTypeNotPass = true;
        } else {
            try {
                mobile = Integer.parseInt(mobileString);
            } catch (Exception d) {
                mobileError.setText("You Should Enter An Integer Number.");
                mobileTypeNotPass = true;
            }
        }

        return !(idEmpty || idTypeNotPass || firstNameEmpty || lastNameEmpty || mobileStringEmpty ||
                mobileTypeNotPass || emailEmpty || addressEmpty || genderEmpty);
    }

    private void resetErrorLabels() {
        idError.setText("");
        firstNameError.setText("");
        lastNameError.setText("");
        mobileError.setText("");
        emailError.setText("");
        addressError.setText("");
        genderError.setText("");
    }

    private void show() throws SQLException, FileNotFoundException, IOException {
        borrowers.clear();
        ResultSet s = statement.executeQuery("select * from borrowers");
        while (s.next()) {
            Borrowers u = new Borrowers(s.getInt("ID"), s.getString("FirstName"), s.getString("LastName"),
                    s.getInt("Mobile"), s.getString("Email"), s.getString("Address"), s.getString("Gender"));
            borrowers.add(u);
        }
        Table.getItems().setAll(borrowers);
        FileWriter fw = new FileWriter(ChoosePageController.logFile, true);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter output = new PrintWriter(bw);
        output.print("***After Clearing Borrowers Array List"
                + " ,Select All Borrowers In Database To Save It Into Borrowers ArrayList. \n");
        output.close();
    }

    private void resetFeilds() {
        idTextFeild.setText("");
        firstNameTextFeild.setText("");
        lastNameTextFeild.setText("");
        mobileTextFeild.setText("");
        emailTextFeild.setText("");
        addressTextFeild.setText("");
        mailReduio.setSelected(false);
        femailReduio.setSelected(false);
    }

}
