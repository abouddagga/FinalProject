/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.project;

import static app.SceneBilders.Managment_BooksController.books;
import static app.SceneBilders.Managment_BorrowersController.borrowers;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.swing.table.TableColumn;
import javax.swing.text.TableView;
import static project.project.Managment_BooksController.books;
import static project.project.Managment_BorrowersController.borrowers;

/**
 * FXML Controller class
 *
 * @author LTC2020   
 */
public class Managment_Borrower_BooksController implements Initializable {

    @FXML
    private TextField bookIdTextFeild;
    @FXML
    private TextField borrowerIdTextFeild;
    @FXML
    private TextField borrorwerDateTextFeild;
    @FXML
    private TextField returnDateTextFeild;
    @FXML
    private TableView<Borrower_Books> Table;
    @FXML
    private TableColumn<Borrower_Books, Integer> bookIdColumn;
    @FXML
    private TableColumn<Borrower_Books, Integer> borrowerIdColumn;
    @FXML
    private TableColumn<Borrower_Books, String> borrowerDateColumn;
    @FXML
    private TableColumn<Borrower_Books, String> returnDateColumn;
    Statement statement;
    public static final ArrayList<Borrower_Books> borrower_books = new ArrayList<>();
    @FXML
    private Label bookIdError;
    @FXML
    private Label borrowerIDError;
    @FXML
    private Label borrowerDateError;
    @FXML
    private Label returnDateError;
    private Object FXMLLoader;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/library?serverTimezone=UTC", "root", "");
            statement = conn.createStatement();
            ResultSet s = statement.executeQuery("select * from borrower_books");
            borrower_books.clear();
            while (s.next()) {
                Borrower_Books u = new Borrower_Books(s.getInt("Book_ID"),
                        s.getInt("Borrower_ID"), s.getString("Borrowers_Data"), s.getString("Return_Data"));
                borrower_books.add(u);
            }
            Table.getItems().setAll(borrower_books);

            FileWriter fw = new FileWriter(ChoosePageController.logFile, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter output = new PrintWriter(bw);
            output.print("***After Clearing Borrower_Books Array List "
                    + ",Select All Borrower_Books In Database To Save It Into Borrower_Books ArrayList And Show It In Table. \n");
            output.close();

            ResultSet s2 = statement.executeQuery("select * from books");
            books.clear();
            while (s2.next()) {
                Books u = new Books(s2.getInt("ID"), s2.getString("Name"), s2.getString("Description"));
                books.add(u);
            }
            FileWriter fw2 = new FileWriter(ChoosePageController.logFile, true);
            BufferedWriter bw2 = new BufferedWriter(fw2);
            PrintWriter output2 = new PrintWriter(bw2);
            output2.print("***After Clearing Books Array List "
                    + ",Select All Books In Database To Save It Into Books ArrayList. \n");
            output2.close();

            ResultSet s3 = statement.executeQuery("select * from borrowers");
            borrowers.clear();
            while (s3.next()) {
                Borrowers u = new Borrowers(s3.getInt("ID"), s3.getString("FirstName"),
                         s3.getString("LastName"), s3.getInt("Mobile"), s3.getString("Email"),
                        s3.getString("Address"), s3.getString("Gender"));
                borrowers.add(u);
            }
            FileWriter fw3 = new FileWriter(ChoosePageController.logFile, true);
            BufferedWriter bw3 = new BufferedWriter(fw3);
            PrintWriter output3 = new PrintWriter(bw3);
            output3.print("***After Clearing Borrowers Array List ,"
                    + "Select All Borrowers In Database To Save It Into Borrowers ArrayList. \n");
            output3.close();

        } catch (Exception ex) {
            Logger.getLogger(LoginPageController.class.getName()).log(Level.SEVERE, null, ex);
        }

        bookIdColumn.setCellValueFactory(new PropertyValueFactory("Book_ID"));
        borrowerIdColumn.setCellValueFactory(new PropertyValueFactory("Borrower_ID"));
        borrowerDateColumn.setCellValueFactory(new PropertyValueFactory("Borrowers_Data"));
        returnDateColumn.setCellValueFactory(new PropertyValueFactory("Return_Data"));
        Table.getSelectionModel().selectedItemProperty().addListener(e -> {
            Borrower_Books b = Table.getSelectionModel().getSelectedItem();
            if (b != null) {
                bookIdTextFeild.setText(String.valueOf(b.getBook_ID()));
                borrowerIdTextFeild.setText(String.valueOf(b.getBorrower_ID()));
                borrorwerDateTextFeild.setText(b.getBorrowers_Data());
                returnDateTextFeild.setText(b.getReturn_Data());
            }
        });

    }

    @FXML
    private void addButtonHandel(ActionEvent event) throws SQLException, FileNotFoundException, IOException {
        if (Validation()) {
            int borrowerId = Integer.parseInt(borrowerIdTextFeild.getText());
            int bookId = Integer.parseInt(bookIdTextFeild.getText());
            String borrorwerDate = borrorwerDateTextFeild.getText();
            String returnDate = returnDateTextFeild.getText();
            boolean foundBorrowerId = false;
            boolean foundBookId = false;

            for (Borrowers a : borrowers) {
                if (a.getId() == borrowerId) {
                    foundBorrowerId = true;
                }
            }

            for (Books a : books) {
                if (a.getId() == bookId) {
                    foundBookId = true;
                }
            }
            if (!foundBorrowerId) {
                borrowerIDError.setText("This ID Is Not Exist In Borrowers List !!!");
            }
            if (!foundBookId) {
                bookIdError.setText("This ID Is Not Exist In Books List !!!");
            }

            if (foundBorrowerId && foundBookId) {
                boolean match = false;
                for (Borrower_Books a : borrower_books) {
                    if (a.getBorrower_ID() == borrowerId && a.getBook_ID() == bookId) {
                        match = true;
                        break;
                    }
                }
                if (!match) {
                    statement.executeUpdate("INSERT INTO borrower_books VALUES (" + bookId + "," + borrowerId + ",'" + borrorwerDate
                            + "','" + returnDate + "')");
                    show();
                    resetFeilds();
                    FileWriter fw = new FileWriter(ChoosePageController.logFile, true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter output = new PrintWriter(bw);
                    output.print("***Add The Book ID : " + bookId + " , Borrower ID : " + borrowerId +
                            " , Borrower Date : '" + borrorwerDate + "' And Rturn Date : '" + returnDate +
                            "' Into borrower_books Table In DataBase. \n");
                    output.close();
                } else {
                    bookIdError.setText("This Book Is Already Have This Borrower");
                    borrowerIDError.setText("This Borrower Is Already Have This Book");
                }
            }
        }

    }

    @FXML
    private void deleteButtonHandel(ActionEvent event) throws SQLException, FileNotFoundException, IOException {
        if (Validation()) {
            int borrowerId = Integer.parseInt(borrowerIdTextFeild.getText());
            int bookId = Integer.parseInt(bookIdTextFeild.getText());
            boolean foundBorrowerId = false;
            boolean foundBookId = false;

            for (Borrowers a : borrowers) {
                if (a.getId() == borrowerId) {
                    foundBorrowerId = true;
                }
            }

            for (Books a : books) {
                if (a.getId() == bookId) {
                    foundBookId = true;
                }
            }
            if (!foundBorrowerId) {
                borrowerIDError.setText("This ID Is Not Exist In Borrowers List !!!");
            }
            if (!foundBookId) {
                bookIdError.setText("This ID Is Not Exist In Books List !!!");
            }

            if (foundBorrowerId && foundBookId) {
                statement.executeUpdate("DELETE FROM borrower_books WHERE Book_ID = " + bookId + " AND 	Borrower_ID = " + borrowerId);
                show();
                resetFeilds();
                FileWriter fw = new FileWriter(ChoosePageController.logFile, true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter output = new PrintWriter(bw);
                output.print("***Delete The Book ID : " + bookId + " And Borrower ID : " + borrowerId + 
                        " From borrower_books Table In DataBase. \n");
                output.close();
            }
        }

    }

    @FXML
    private void updateButtonHandel(ActionEvent event) throws SQLException, FileNotFoundException, IOException {
        if (Validation()) {
            int borrowerId = Integer.parseInt(borrowerIdTextFeild.getText());
            int bookId = Integer.parseInt(bookIdTextFeild.getText());
            String borrorwerDate = borrorwerDateTextFeild.getText();
            String returnDate = returnDateTextFeild.getText();
            boolean foundBorrowerId = false;
            boolean foundBookId = false;

            for (Borrowers a : borrowers) {
                if (a.getId() == borrowerId) {
                    foundBorrowerId = true;
                }
            }

            for (Books a : books) {
                if (a.getId() == bookId) {
                    foundBookId = true;
                }
            }
            if (!foundBorrowerId) {
                borrowerIDError.setText("This ID Is Not Exist In Borrowers List !!!");
            }
            if (!foundBookId) {
                bookIdError.setText("This ID Is Not Exist In Books List !!!");
            }

            if (foundBorrowerId && foundBookId) {
                statement.executeUpdate("UPDATE borrower_books SET Borrowers_Data = '" + borrorwerDate + 
                        "' , Return_Data = '" + returnDate + "' WHERE Book_ID = " + bookId + " AND Borrower_ID = " + borrowerId);
                show();
                resetFeilds();
                FileWriter fw = new FileWriter(ChoosePageController.logFile, true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter output = new PrintWriter(bw);
                output.print("***Update The Borrowers_Data : '" + borrorwerDate + "' And Return_Data : '" + 
                        returnDate + "' Thats Have  Book ID : " + bookId + " And Borrower ID : " + borrowerId +
                        " From borrower_books Table In DataBase. \n");
                output.close();
            }
        }

    }

    @FXML
    private void searchButtonHandel(ActionEvent event) {
        resetErrorLabels();
        String bookIdString = bookIdTextFeild.getText();
        String borrowerIdString = borrowerIdTextFeild.getText();

        Integer bookId = null;
        Integer borrowerId = null;

        boolean bookIdTypeNotPass = false;
        boolean borrowerIdTypeNotPass = false;

        boolean bookIdStringEmpty = bookIdString.equals("");
        boolean borrowerIdStringEmpty = borrowerIdString.equals("");

        if (bookIdStringEmpty) {
            bookIdError.setText("Empty Book ID!!");
        } else {
            try {
                bookId = Integer.parseInt(bookIdString);
            } catch (Exception d) {
                bookIdError.setText("You Should Enter An Integer Number.");
                bookIdTypeNotPass = true;
            }
        }
        if (borrowerIdStringEmpty) {
            borrowerIDError.setText("Empty Borrower ID !!");
        } else {
            try {
                borrowerId = Integer.parseInt(borrowerIdString);
            } catch (Exception d) {
                borrowerIDError.setText("You Should Enter An Integer Number.");
                borrowerIdTypeNotPass = true;
            }
        }

        boolean v = !(bookIdTypeNotPass || borrowerIdTypeNotPass || bookIdStringEmpty || borrowerIdStringEmpty);
        if (v) {
            boolean match = false;
            Borrower_Books bbr = null;
            for (Borrower_Books a : borrower_books) {
                if (a.getBorrower_ID() == borrowerId && a.getBook_ID() == bookId) {
                    match = true;
                    bbr = a;
                    break;
                }
            }
            if (match) {
                borrorwerDateTextFeild.setText(bbr.getBorrowers_Data());
                returnDateTextFeild.setText(bbr.getReturn_Data());
            } else {
                bookIdError.setText("This Book Is Have Have This Borrower");
                borrowerIDError.setText("This Borrower Is Not Have This Book");
            }

        }
    }

    @FXML
    private void backButtonHandel(ActionEvent event) throws IOException {
        Parent p = FXMLLoader.load(this.getClass().getResource("ChoosePage.fxml"));
        Scene scene = new Scene(p, 1366, 700);
        Main.setNewScene(scene);
    }

    private boolean Validation() {
        resetErrorLabels();
        String bookIdString = bookIdTextFeild.getText();
        String borrowerIdString = borrowerIdTextFeild.getText();
        String borrorwerDate = borrorwerDateTextFeild.getText();
        String returnDate = returnDateTextFeild.getText();

        Integer bookId = null;
        Integer borrowerId = null;

        boolean bookIdTypeNotPass = false;
        boolean borrowerIdTypeNotPass = false;

        boolean bookIdStringEmpty = bookIdString.equals("");
        boolean borrowerIdStringEmpty = borrowerIdString.equals("");
        boolean borrorwerDateEmpty = borrorwerDate.equals("");
        boolean returnDateEmpty = returnDate.equals("");

        if (bookIdStringEmpty) {
            bookIdError.setText("Empty Book ID!!");
        } else {
            try {
                bookId = Integer.parseInt(bookIdString);
            } catch (Exception d) {
                bookIdError.setText("You Should Enter An Integer Number.");
                bookIdTypeNotPass = true;
            }
        }
        if (borrowerIdStringEmpty) {
            borrowerIDError.setText("Empty Borrower ID !!");
        } else {
            try {
                borrowerId = Integer.parseInt(borrowerIdString);
            } catch (Exception d) {
                borrowerIDError.setText("You Should Enter An Integer Number.");
                borrowerIdTypeNotPass = true;
            }
        }

        if (borrorwerDateEmpty) {
            borrowerDateError.setText("Empty Borrower Date !!");
        }

        if (returnDateEmpty) {
            returnDateError.setText("Empty Return Date !!");
        }

        return !(bookIdTypeNotPass || borrowerIdTypeNotPass || bookIdStringEmpty
                || borrowerIdStringEmpty || borrorwerDateEmpty || returnDateEmpty);
    }

    private void resetErrorLabels() {
        bookIdError.setText("");
        borrowerIDError.setText("");
        borrowerDateError.setText("");
        returnDateError.setText("");
    }

    private void show() throws SQLException, FileNotFoundException, IOException {
        borrower_books.clear();
        ResultSet s = statement.executeQuery("select * from borrower_books");
        while (s.next()) {
            Borrower_Books u = new Borrower_Books(s.getInt("Book_ID"),
                    s.getInt("Borrower_ID"), s.getString("Borrowers_Data"), s.getString("Return_Data"));
            borrower_books.add(u);
        }
        Table.getItems().setAll(borrower_books);
        FileWriter fw = new FileWriter(ChoosePageController.logFile, true);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter output = new PrintWriter(bw);
        output.print("***After Clearing Borrower_Books Array List ,"
                + " Select All Borrower_Books In Database To Save It Into Borrower_Books ArrayList And Show It In Table. \n");
        output.close();

    }

    private void resetFeilds() {
        bookIdTextFeild.setText("");
        borrowerIdTextFeild.setText("");
        borrorwerDateTextFeild.setText("");
        returnDateTextFeild.setText("");
    }

}
