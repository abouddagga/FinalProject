package project.project;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author LTC2020  
 */
public class Main extends Application {

    private static Scene scene;
    private static Stage stage = new Stage();
    private Object FXMLLoader;

    @Override
    public void start(Stage primaryStage) throws Exception {

        scene = new Scene(FXMLLoader.load(this.getClass().getResource("LoginPage.fxml")), 1366, 700);
        stage.setTitle("");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    public static void setNewScene(Scene s) {
        scene = s;
        stage.setScene(s);
        stage.show();
    }

}
